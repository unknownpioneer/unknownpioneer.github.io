"""习题3：继续完成 word1.docx 的编辑与排版（7 项要求）。

输出：结果/习题3_word1_排版完成.docx
"""
import sys, os, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docxhlp import (el, sub, set_run_font, set_para_columns, add_field,
                     set_bg_shading, W)

SRC = 'word1.docx'
OUT = os.path.join('结果', '习题3_word1_排版完成.docx')

WINDDINGS_BULLET = '\u2751'          # Wingdings 十进制 175
WINDDINGS_TITLE_SYM = '\u2751'       # Wingdings 十进制 83 -> ❑ (见说明.md)

LIGHT_BLUE = '00B0F0'
RED = 'FF0000'
YELLOW = 'FFFF00'


def clear_runs(p):
    for r in list(p.runs):
        r._element.getparent().remove(r._element)


def _clone_cols_sect(base_sectPr, num, space_twips=425):
    """复制原有节属性，仅把栏数改为 num —— 保证页面大小/页边距不变。"""
    import copy as _copy
    sect = _copy.deepcopy(base_sectPr)
    old = sect.find(qn('w:cols'))
    if old is not None:
        sect.remove(old)
    cols = OxmlElement('w:cols')
    cols.set(qn('w:space'), str(space_twips))
    if num > 1:
        cols.set(qn('w:num'), str(num))
        cols.set(qn('w:equalWidth'), '1')
    sect.append(cols)
    return sect


def _attach_sectpr(paragraph, sectPr):
    """把节属性挂到段落上，即该段落之后分节。"""
    pPr = paragraph._element.get_or_add_pPr()
    old = pPr.find(qn('w:sectPr'))
    if old is not None:
        pPr.remove(old)
    pPr.append(sectPr)


def new_num(numbering_part):
    """Insert an abstractNum + num pair, returning the new numId."""
    root = numbering_part.element
    abs_ids = [int(a.get(qn('w:abstractNumId')))
               for a in root.findall(qn('w:abstractNum'))]
    new_abs = max(abs_ids) + 1 if abs_ids else 0
    an = OxmlElement('w:abstractNum')
    an.set(qn('w:abstractNumId'), str(new_abs))
    an.append(el('w:nsid', val='%08X' % (0x2A000000 + new_abs)))
    an.append(el('w:multiLevelType', val='hybridMultilevel'))
    lvl = OxmlElement('w:lvl')
    lvl.set(qn('w:ilvl'), '0')
    lvl.append(el('w:start', val='1'))
    lvl.append(el('w:numFmt', val='bullet'))
    lvl.append(el('w:lvlText', val=WINDDINGS_BULLET))
    lvl.append(el('w:lvlJc', val='left'))
    pPr = OxmlElement('w:pPr')
    pPr.append(el('w:ind', left='840', hanging='425'))
    lvl.append(pPr)
    rPr = OxmlElement('w:rPr')
    rf = OxmlElement('w:rFonts')
    rf.set(qn('w:ascii'), 'Wingdings')
    rf.set(qn('w:hAnsi'), 'Wingdings')
    rf.set(qn('w:hint'), 'default')
    rPr.append(rf)
    rPr.append(el('w:color', val=LIGHT_BLUE))
    lvl.append(rPr)
    an.append(lvl)

    first_num = root.find(qn('w:num'))
    if first_num is not None:
        first_num.addprevious(an)
    else:
        root.append(an)

    num_ids = [int(n.get(qn('w:numId'))) for n in root.findall(qn('w:num'))]
    new_num_id = max(num_ids) + 1 if num_ids else 1
    n = OxmlElement('w:num')
    n.set(qn('w:numId'), str(new_num_id))
    n.append(el('w:abstractNumId', val=str(new_abs)))
    root.append(n)
    return new_num_id


def main():
    os.makedirs('结果', exist_ok=True)
    doc = Document(SRC)
    ps = doc.paragraphs
    assert len(ps) >= 14, len(ps)

    # 字符数（不计空格）—— 用于第 ⑤ 项。
    # 说明：正文段落从第一个正文段（"洞指的是……"）开始编号，故
    #   paragraphs[1] = 首字下沉的"溶"（不在正文编号内）
    #   paragraphs[2] = 正文第 1 段"洞指的是……"
    #   paragraphs[3] = 正文第 2 段"中国是个多溶洞的国家……"（样文值 388）
    # 样文 word1.pdf 中第 3 段后填写的正是 388，与此一致。
    body2 = ps[3].text
    count2 = len(body2.replace(' ', '').replace('\u3000', ''))

    # ---------- ① 标题：楷体、加粗、30 号、标准色红色、浅蓝色双下划线 + Wingdings 字符 ----------
    title = ps[0]
    clear_runs(title)
    r = title.add_run('溶洞')
    set_run_font(r, ascii_font='楷体', ea_font='楷体', size=30, bold=True,
                 color=RED, underline=None)
    # 双下划线 + 浅蓝色
    rPr = r._element.get_or_add_rPr()
    u = OxmlElement('w:u')
    u.set(qn('w:val'), 'double')
    u.set(qn('w:color'), LIGHT_BLUE)
    rPr.append(u)
    rs = title.add_run(WINDDINGS_TITLE_SYM)
    set_run_font(rs, ascii_font='Wingdings', ea_font='Wingdings', size=30,
                 color=LIGHT_BLUE)

    # ---------- ② 正文第 1 段：段前段后 1.5 行 ----------
    p1 = ps[1]
    p1.paragraph_format.space_before = Pt(1.5 * 12)
    p1.paragraph_format.space_after = Pt(1.5 * 12)

    # ---------- ⑤ 正文第 3 段后填写字符数 ----------
    p4 = ps[4]
    rf = p4.add_run(' ' + str(count2))
    set_run_font(rf, ascii_font='Times New Roman', ea_font='宋体')

    # ---------- ③ 红色字体段落加项目符号 + 三栏 ----------
    # 分节：ps[0..5] 为单栏节（标题与正文首段），ps[6..12] 为三栏节（红色字体段落），
    #      ps[13] 回到单栏节。
    red_idx = list(range(6, 13))
    numbering = doc.part.numbering_part
    nid = new_num(numbering)
    for i in red_idx:
        p = ps[i]
        pPr = p._element.get_or_add_pPr()
        old = pPr.find(qn('w:numPr'))
        if old is not None:
            pPr.remove(old)
        numPr = OxmlElement('w:numPr')
        numPr.append(el('w:ilvl', val='0'))
        numPr.append(el('w:numId', val=str(nid)))
        pPr.insert(0, numPr)
    # 先把整节设为单栏，再在红色段落末尾插入三栏节
    base = doc.sections[0]._sectPr
    single = _clone_cols_sect(base, 1)
    _attach_sectpr(ps[5], single)
    triple = _clone_cols_sect(base, 3)
    _attach_sectpr(ps[12], triple)

    # ---------- ④ 正文最后 1 段：段前 0.5 行、隶书、小四、黄色底纹 ----------
    last = ps[13]
    last.paragraph_format.space_before = Pt(0.5 * 12)
    for r in last.runs:
        set_run_font(r, ascii_font='隶书', ea_font='隶书', size=12)
        set_bg_shading(r, YELLOW)

    # ---------- ⑥ 纸张纵向、自定义 20×20 厘米、四周页边距 2 厘米 ----------
    from docx.shared import Cm
    from docx.enum.section import WD_ORIENT
    for sec in doc.sections:
        sec.orientation = WD_ORIENT.PORTRAIT
        sec.page_width = Cm(20)
        sec.page_height = Cm(20)
        sec.top_margin = Cm(2)
        sec.bottom_margin = Cm(2)
        sec.left_margin = Cm(2)
        sec.right_margin = Cm(2)

    doc.save(OUT)
    print('saved:', OUT)
    print('字符数(不计空格) of 正文第2段 =', count2)


if __name__ == '__main__':
    main()
