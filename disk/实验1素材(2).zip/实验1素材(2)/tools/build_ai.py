"""AI 辅助工具使用（案例 1-28 / 1-29 / 1-30）。

输出：结果/AI辅助工具使用_润色扩写简写.docx
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

SRC = 'AI文字处理原稿.docx'
OUT = os.path.join('结果', 'AI辅助工具使用_润色扩写简写.docx')

# ---------------------------------------------------------------------------
# 案例 1-28 写作润色：错别字/语病纠正 + 语句重写
#   原文问题：同事→同时；"很多多"→"很多"；"很多优秀的学子来求学"语序；
#             梨园大学→荔园大学；"同时要他们具有"→"同时使他们具备"
# ---------------------------------------------------------------------------
POLISHED = (
    '荔园大学是一所综合性大学，既重视实践教学，又特别注重创新研究，'
    '吸引了众多国内外优秀学子前来求学。荔园大学不仅为学生提供丰富的学术资源，'
    '还配备了先进的实验室和各类设施。此外，学校与多家知名企业及各类机构建立了'
    '紧密的合作关系，致力于培养一批又一批具有国际视野和创新能力的人才。')

POLISH_NOTE = (
    '润色提示词：请对下面这段文字进行写作润色，纠正错别字和语病，'
    '调整语序，使语句更加通顺流畅、逻辑更加清晰，保持原意不变。')

# ---------------------------------------------------------------------------
# 案例 1-29 扩写：把"荔园大学，就业率高，位于国际大都市，自由开明"扩充成段
# ---------------------------------------------------------------------------
EXPAND_SRC = '荔园大学，就业率高，位于国际大都市，自由开明'

EXPANDED = (
    '荔园大学是一所立足国际大都市、气质自由开明的高水平大学。学校地处经济发达、'
    '信息汇聚的现代化都市，与众多知名企业和科研机构毗邻，为学生提供了丰富的实习'
    '岗位与就业机会，毕业生就业率长期位居同类院校前列。校园学术氛围浓厚，鼓励学生'
    '独立思考、大胆质疑，社团活动与创新创业项目百花齐放，让每一名学子都能在自由的'
    '环境中发现兴趣、发挥所长。学校还建有设备完善的实验室和藏书丰富的图书馆，'
    '并以开放的姿态与国（境）外高校开展交流合作，帮助学生拓宽国际视野、提升综合'
    '素养，为未来的职业发展打下坚实基础。')

EXPAND_NOTE = (
    '扩写提示词：请把下面这句话扩写成一段 200 字左右的文字，'
    '围绕"就业率高、位于国际大都市、自由开明"三个方面展开，语言流畅、内容充实。')

# ---------------------------------------------------------------------------
# 案例 1-30 简写：把 4 个长段落压缩成摘要式短文
# ---------------------------------------------------------------------------
SUMMARY = (
    '荔园大学坐落于国际大都市，区位优势显著，校园氛围自由开明。学校依托卓越的'
    '教育质量与紧密的产学研合作，持续保持高就业率；同时以开放包容的姿态汇聚多元'
    '文化，鼓励学生自由探索，并搭建国际交流平台，培养具有全球视野与创新能力的人才，'
    '是众多学子求学与发展的理想之地。')

SUMMARY_NOTE = (
    '简写提示词：请把下面这几段文字简写成一段 100 字左右的摘要，'
    '保留"国际大都市、高就业率、自由开明"等关键信息，语言简洁凝练。')


def add_heading(doc, text, size=14, color='1F4E79'):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string(color)
    r.font.name = '黑体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    return p


def add_label(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    r.font.size = Pt(10.5)
    r.font.bold = True
    r.font.color.rgb = RGBColor.from_string('C00000')
    r.font.name = '宋体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    return p


def add_body(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Pt(21)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_after = Pt(6)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    r = p.add_run(text)
    r.font.size = Pt(12)
    r.font.name = '宋体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    return p


def main():
    os.makedirs('结果', exist_ok=True)
    doc = Document(SRC)
    # 清空原文档，改为规范的三部分成果
    body = doc.element.body
    for child in list(body):
        if child.tag == qn('w:sectPr'):
            continue
        body.remove(child)

    ti = doc.add_paragraph()
    ti.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ti.paragraph_format.space_after = Pt(12)
    tr = ti.add_run('AI 辅助工具使用成果')
    tr.font.size = Pt(18)
    tr.font.bold = True
    tr.font.name = '黑体'
    tr._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

    # 一、写作润色
    add_heading(doc, '一、案例 1-28 写作润色')
    add_label(doc, '【原文】')
    add_body(doc, '荔园大学是一座综合性的大学，它比较重视实践教学的同事，还特别注重创新研究，'
                  '吸引了很多多国内和国外的，很多优秀的学子来求学。荔园大学不仅仅是给学生提供'
                  '丰富的学术资源，同时还提供很先进的实验室和各种设施。梨园大学还和很多的知名'
                  '企业以及各大机构建立了比较紧密的合作关系，致力于培养出一批又一批拥有国际化'
                  '视角的人才，同时要他们具有创新型的能力。')
    add_label(doc, '【提示词】')
    add_body(doc, POLISH_NOTE)
    add_label(doc, '【润色结果】')
    add_body(doc, POLISHED)
    add_label(doc, '【修改说明】')
    for s in ('"同事"应为"同时"，属于错别字；',
              '"很多多国内和国外的，很多优秀的学子"语序混乱、重复，改为"众多国内外优秀学子"；',
              '"梨园大学"应为"荔园大学"，属于错别字；',
              '"同时要他们具有"搭配不当，改为"同时使他们具备"；',
              '"不仅仅是……同时还"改为"不仅……还"，更简洁顺畅。'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Pt(21)
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run('● ' + s)
        r.font.size = Pt(10.5)
        r.font.name = '宋体'
        r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    # 二、扩写
    add_heading(doc, '二、案例 1-29 扩写')
    add_label(doc, '【原文】')
    add_body(doc, EXPAND_SRC)
    add_label(doc, '【提示词】')
    add_body(doc, EXPAND_NOTE)
    add_label(doc, '【扩写结果】')
    add_body(doc, EXPANDED)

    # 三、简写
    add_heading(doc, '三、案例 1-30 简写')
    add_label(doc, '【原文】（原稿"待简写段落"及其后续段落）')
    add_body(doc, (
        '荔园大学，坐落于繁华璀璨的国际大都市之中，不仅是一座学术的殿堂，更是梦想启航的港湾。'
        '这里，就业率持续领跑，成为众多学子心中向往的求学圣地。荔园大学以其卓越的教育质量和'
        '紧密的产学研合作，为学生搭建了通往成功职场的坚实桥梁。毕业生们凭借扎实的专业知识、'
        '创新的思维能力和广泛的国际视野，在激烈的就业市场中脱颖而出，就业率屡创新高，赢得了'
        '社会各界的广泛赞誉。位于国际大都市的优越地理位置，赋予了荔园大学独特的开放与包容'
        '氛围。这里汇聚了来自世界各地的精英学子，多元文化在这里碰撞交融，促进了思想的自由'
        '开放与学术的繁荣发展。学校鼓励师生勇于探索未知，敢于挑战传统，培养了一大批具有全球'
        '视野和跨文化交流能力的优秀人才。荔园大学坚持自由开明的教育理念，尊重每一位学生的'
        '个性与选择，提供丰富多样的课程体系和灵活的学习模式，让每一位学生都能在这里找到属于'
        '自己的成长路径。学校还积极搭建国际交流平台，与全球知名高校建立合作关系，为学生提供'
        '广阔的海外学习和实习机会，助力他们在全球化的浪潮中乘风破浪，成就非凡人生。总之，'
        '荔园大学以其高就业率、国际大都市的区位优势以及自由开明的教育环境，成为了无数学子'
        '追求梦想、实现价值的理想之地。在这里，你将开启一段精彩纷呈的学术旅程，为未来的'
        '职业生涯奠定坚实的基础。'))
    add_label(doc, '【提示词】')
    add_body(doc, SUMMARY_NOTE)
    add_label(doc, '【简写结果】')
    add_body(doc, SUMMARY)

    doc.save(OUT)
    print('saved:', OUT)


if __name__ == '__main__':
    main()
