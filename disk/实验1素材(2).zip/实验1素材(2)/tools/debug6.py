import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream, parse_tounicode, build_fonts

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
sd = get_stream(objs[623])
cm = parse_tounicode(sd)
print('048F ->', repr(cm.get(0x048F)))
for m in re.finditer(rb'beginbfrange(.*?)endbfrange', sd, re.S):
    blk = m.group(1)
    hits = [x for x in re.finditer(rb'<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>', blk) if int(x.group(1), 16) <= 0x48F <= int(x.group(2), 16)]
    if hits:
        print('HIT', hits[0].group(0))
print('total', len(cm), 'max key', max(cm))
