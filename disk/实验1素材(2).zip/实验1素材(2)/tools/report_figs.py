"""为实验报告生成插图（结果预览图 / 对话框参数卡片 / 截图裁切）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image
from docx_render import render_docx, render_plain, CM

OUTDIR = os.path.join('结果', '报告图片')
os.makedirs(OUTDIR, exist_ok=True)


def trim(path, top, bottom=None, left=0, right=None):
    im = Image.open(path)
    w, h = im.size
    bottom = h if bottom is None else bottom
    right = w if right is None else right
    return im.crop((left, top, right, bottom))


def save_trim(src, dst, top, bottom=None, left=0, right=None):
    im = trim(src, top, bottom, left, right)
    im.save(dst)
    return dst


def hstack(paths, gap=10, bg='#FFFFFF'):
    ims = [Image.open(p) for p in paths]
    H = max(i.height for i in ims)
    W = sum(i.width for i in ims) + gap * (len(ims) - 1)
    canvas = Image.new('RGB', (W, H), bg)
    x = 0
    for i in ims:
        canvas.paste(i, (x, 0))
        x += i.width + gap
    return canvas


def crop_screenshot(src, dst, box):
    """box = (left, top, right, bottom) 相对 1920x1080 原图。"""
    im = Image.open(src).convert('RGB')
    w, h = im.size
    sx, sy = w / 1920.0, h / 1080.0
    l, t, r, b = box
    im2 = im.crop((int(l * sx), int(t * sy), int(r * sx), int(b * sy)))
    im2.save(dst)
    return dst


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    print('helper module; run build_report.py')
