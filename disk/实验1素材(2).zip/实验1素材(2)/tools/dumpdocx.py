import sys
from docx import Document

path = sys.argv[1]
out = sys.argv[2]
doc = Document(path)
lines = []
body = doc.element.body
from docx.table import Table
from docx.text.paragraph import Paragraph

def iter_block_items(parent):
    from docx.oxml.ns import qn
    for child in parent.element.body.iterchildren():
        if child.tag == qn('w:p'):
            yield Paragraph(child, parent)
        elif child.tag == qn('w:tbl'):
            yield Table(child, parent)

for block in iter_block_items(doc):
    if isinstance(block, Paragraph):
        t = block.text.strip()
        style = block.style.name if block.style is not None else ''
        if t:
            lines.append(('[%s] ' % style if style and style != 'Normal' else '') + t)
    else:
        lines.append('--- TABLE ---')
        for row in block.rows:
            cells = [c.text.strip().replace('\n', ' / ') for c in row.cells]
            lines.append(' | '.join(cells))
        lines.append('--- END TABLE ---')

with open(out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print('paragraphs/tables written:', len(lines))
