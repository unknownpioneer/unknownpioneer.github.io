"""Minimal PDF text extractor for CID/Identity-H fonts using ToUnicode CMaps.

Parses the PDF object table (including Flate-compressed object streams), builds
font -> CID->Unicode maps, then walks each page's content stream emitting text
in reading order (grouped by BT/ET text objects and Td/TD/T*/Tm advances).
"""
import re, zlib, sys


def load(path):
    d = open(path, 'rb').read()
    objs = {}
    for m in re.finditer(rb'(\d+)\s+0\s+obj', d):
        num = int(m.group(1))
        start = m.end()
        e = d.find(b'endobj', start)
        objs[num] = d[start:e]
    for n, o in list(objs.items()):
        if b'/ObjStm' in o[:400] and b'stream' in o:
            m2 = re.search(rb'stream\r?\n', o)
            if not m2:
                continue
            raw = o[m2.end():o.rfind(b'endstream')]
            try:
                dec = zlib.decompress(raw)
            except Exception:
                continue
            hdr = o[:m2.start()]
            nm = re.search(rb'/N\s+(\d+)', hdr)
            fm = re.search(rb'/First\s+(\d+)', hdr)
            N = int(nm.group(1)) if nm else 0
            F = int(fm.group(1)) if fm else 0
            try:
                nums = [int(x) for x in dec[:F].split()]
            except ValueError:
                continue
            body = dec[F:]
            for i in range(N):
                if 2 * i + 1 >= len(nums):
                    break
                onum = nums[2 * i]
                off = nums[2 * i + 1]
                end = nums[2 * i + 3] if (2 * i + 3) < len(nums) and i + 1 < N else len(body)
                objs[onum] = body[off:end]
            del objs[n]
    return d, objs


def get_stream(obj):
    m = re.search(rb'stream\r?\n', obj)
    if not m:
        return None
    raw = obj[m.end():obj.rfind(b'endstream')]
    hdr = obj[:m.start()]
    if b'FlateDecode' in hdr:
        try:
            return zlib.decompress(raw)
        except Exception:
            try:
                return zlib.decompressobj().decompress(raw)
            except Exception:
                return None
    return raw


def parse_tounicode(data):
    cmap = {}
    for m in re.finditer(rb'beginbfchar(.*?)endbfchar', data, re.S):
        for mm in re.finditer(rb'<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>', m.group(1)):
            src = int(mm.group(1), 16)
            h = mm.group(2).decode()
            cmap[src] = ''.join(chr(int(h[i:i + 4], 16)) for i in range(0, len(h), 4))
    RANGE_ENTRY = re.compile(
        rb'<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(?:<([0-9A-Fa-f]+)>|\[(.*?)\])', re.S)
    for m in re.finditer(rb'beginbfrange(.*?)endbfrange', data, re.S):
        for mm in RANGE_ENTRY.finditer(m.group(1)):
            a = int(mm.group(1), 16)
            b = int(mm.group(2), 16)
            if mm.group(3) is not None:
                c = int(mm.group(3), 16)
                for k in range(a, b + 1):
                    cmap[k] = chr(c + (k - a))
            else:
                items = re.findall(rb'<([0-9A-Fa-f]+)>', mm.group(4))
                for i, it in enumerate(items):
                    h = it.decode()
                    cmap[a + i] = ''.join(chr(int(h[j:j + 4], 16)) for j in range(0, len(h), 4))
    return cmap


def build_fonts(objs):
    fonts = {}
    for n, o in objs.items():
        if b'/BaseFont' in o:
            bf = re.search(rb'/BaseFont\s*/([^\s/>\]]+)', o)
            tu = re.search(rb'/ToUnicode\s+(\d+)\s+0\s+R', o)
            cmap = {}
            if tu:
                so = objs.get(int(tu.group(1)))
                if so is not None:
                    sd = get_stream(so)
                    if sd:
                        cmap = parse_tounicode(sd)
            fonts[n] = (bf.group(1).decode('latin1') if bf else '?', cmap)
    return fonts


def resolve_dict(objs, ref_bytes):
    m = re.search(rb'(\d+)\s+0\s+R', ref_bytes)
    if not m:
        return None, None
    n = int(m.group(1))
    return n, objs.get(n)


def page_objects(objs):
    pages = [(n, o) for n, o in objs.items() if re.search(rb'/Type\s*/Page[^s]', o)]
    pages.sort()
    return pages


TOK = re.compile(
    rb'/([A-Za-z0-9]+)\s+[-\d.]+\s+Tf'          # 1 font
    rb'|<([0-9A-Fa-f\s]*)>\s*Tj'                # 2 hex Tj
    rb'|\(((?:\\\\.|[^\\()])*)\)\s*Tj'          # 3 literal Tj
    rb'|\[(.*?)\]\s*TJ'                         # 4 TJ array
    rb'|(T\*|Td|TD|Tm|BT|ET)',                  # 5 ops
    re.S)


def decode_hex(h, fontmap, curfont):
    bf, cmap = fontmap.get(curfont, ('?', {}))
    h = re.sub(rb'\s', b'', h).decode()
    out = ''
    step = 4
    for i in range(0, len(h) - step + 1, step):
        cid = int(h[i:i + step], 16)
        out += cmap.get(cid, '\ufffd')
    return out


def decode_literal(s, fontmap, curfont):
    bf, cmap = fontmap.get(curfont, ('?', {}))
    try:
        b = s.decode('latin1')
    except Exception:
        return ''
    out = ''
    for ch in b:
        cid = ord(ch)
        out += cmap.get(cid, ch if cid >= 32 else '')
    return out


def extract_page(objs, po, fontmap):
    res_ref = re.search(rb'/Resources\s+(\d+)\s+0\s+R', po)
    res = objs.get(int(res_ref.group(1)), b'') if res_ref else po
    if isinstance(res, bytes) and b'/Font' not in res:
        _, r2 = resolve_dict(objs, res)
        if r2:
            res = r2
    fmap = {}
    fm = re.search(rb'/Font\s*<<(.*?)>>', res, re.S)
    if not fm:
        _, resd = resolve_dict(objs, res)
        if resd:
            fm = re.search(rb'/Font\s*<<(.*?)>>', resd, re.S)
    if fm:
        for mm in re.finditer(rb'/([A-Za-z0-9]+)\s+(\d+)\s+0\s+R', fm.group(1)):
            fmap[mm.group(1).decode()] = int(mm.group(2))

    conts = []
    cm = re.search(rb'/Contents\s+(\d+)\s+0\s+R', po)
    if cm:
        conts = [int(cm.group(1))]
    else:
        cm2 = re.search(rb'/Contents\s*\[(.*?)\]', po, re.S)
        if cm2:
            conts = [int(x) for x in re.findall(rb'(\d+)\s+0\s+R', cm2.group(1))]
    data = b''
    for c in conts:
        if c in objs:
            sd = get_stream(objs[c])
            if sd:
                data += sd + b'\n'

    lines = []
    cur = ''
    curfont = None
    lasty = None
    for m in TOK.finditer(data):
        if m.group(1):
            name = m.group(1).decode()
            curfont = fmap.get(name)
        elif m.group(2) is not None:
            cur += decode_hex(m.group(2), fontmap, curfont)
        elif m.group(3) is not None:
            cur += decode_literal(m.group(3), fontmap, curfont)
        elif m.group(4) is not None:
            for part in re.finditer(rb'<([0-9A-Fa-f\s]*)>|\(((?:\\.|[^\\()])*)\)', m.group(4), re.S):
                if part.group(1) is not None:
                    cur += decode_hex(part.group(1), fontmap, curfont)
                elif part.group(2) is not None:
                    cur += decode_literal(part.group(2), fontmap, curfont)
        else:
            op = m.group(5)
            if op in (b'Td', b'TD', b'Tm', b'T*'):
                if cur.strip():
                    lines.append(cur)
                cur = ''
            elif op == b'ET':
                if cur.strip():
                    lines.append(cur)
                cur = ''
    if cur.strip():
        lines.append(cur)
    return lines


def extract(path, out):
    d, objs = load(path)
    fontmap = build_fonts(objs)
    pages = page_objects(objs)
    with open(out, 'w', encoding='utf-8') as f:
        for idx, (pn, po) in enumerate(pages, 1):
            lines = extract_page(objs, po, fontmap)
            f.write('\n===== PAGE %d (obj %d) =====\n' % (idx, pn))
            for l in lines:
                f.write(l.rstrip() + '\n')
    print('pages:', len(pages), '->', out)


if __name__ == '__main__':
    extract(sys.argv[1], sys.argv[2])
