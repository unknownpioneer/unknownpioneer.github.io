import sys, re, collections
sys.path.insert(0, 'tools')
from pdftext import load, get_stream
d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
sd = get_stream(objs[52]).decode('latin1')
ops = collections.Counter(re.findall(r'(?<![A-Za-z0-9/])([A-Za-z*\'"]{1,3})(?=[\s\]])', sd))
print(ops.most_common(30))
s = re.findall(r'\((.*?)\)', sd, re.S)
nz = [x for x in s if x.strip()]
print('paren nonempty', len(nz), nz[:20])
print('hex', re.findall(r'<([0-9A-Fa-f]+)>', sd)[:10])
print('Do', sd.count('/Do'), 'len', len(sd))
print('TJ', sd.count('TJ'), 'Tj', sd.count('Tj'))
