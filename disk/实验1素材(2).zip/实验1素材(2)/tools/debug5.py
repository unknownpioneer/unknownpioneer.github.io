import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
sd = get_stream(objs[623]).decode('latin1')
print(sd[:1200])
print('...')
print(sd[-1500:])
