import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
for n, o in sorted(objs.items()):
    if b'/BaseFont' in o and b'/ToUnicode' in o:
        bf = re.search(rb'/BaseFont\s*/([^\s/>\]]+)', o)
        tu = re.search(rb'/ToUnicode\s+(\d+)\s+0\s+R', o)
        sub = re.search(rb'/Subtype\s*/(\w+)', o)
        enc = re.search(rb'/Encoding\s*/?([\w-]+)?', o)
        sd = get_stream(objs.get(int(tu.group(1)), b''))
        print('FONT obj', n, 'base', bf.group(1) if bf else None, 'sub', sub.group(1) if sub else None,
              'tu_len', len(sd) if sd else None)
        if sd:
            head = sd[:400].decode('latin1', 'replace')
            print('   ', head.replace('\n', ' | ')[:380])
        print()
