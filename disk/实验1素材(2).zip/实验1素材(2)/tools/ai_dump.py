from docx import Document
d = Document('AI文字处理原稿.docx')
with open('tools/ai_src.txt', 'w', encoding='utf-8') as f:
    for i, p in enumerate(d.paragraphs):
        f.write('[%d] style=%s align=%s line=%s | %r\n' % (
            i, p.style.name, p.paragraph_format.alignment,
            p.paragraph_format.line_spacing, p.text))
        for j, r in enumerate(p.runs):
            f.write('     run%d %r sz=%s b=%s\n' % (
                j, r.text[:40], r.font.size.pt if r.font.size else None, r.font.bold))
print('ok')
