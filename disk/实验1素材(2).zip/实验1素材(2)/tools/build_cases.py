"""生成报告所需的案例文档与插图。

  case1-1 : 在个人简历中插入书签"可溶性岩石"
  case1-3 : 在"溶洞"一句后插入 Wingdings 十进制 83 符号
  case1-23: 在论文第 1 节空白页插入目录（Word 目录域）
"""
import os, sys, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docxhlp import set_run_font

RES = '结果'
FIG = os.path.join(RES, '报告图片')
os.makedirs(FIG, exist_ok=True)
SYM = '\u2751'   # Wingdings 十进制 83


def case11_bookmark():
    """案例1-1：书签的插入与定位。"""
    doc = Document('个人简历.docx')
    ps = [p for p in doc.paragraphs if p.text.strip()]
    target = None
    for p in ps:
        if p.text.strip().startswith('个人概况'):
            target = p
            break
    assert target is not None
    # 在"个人概况"后加书签
    pPr = target._element
    bs = OxmlElement('w:bookmarkStart')
    bs.set(qn('w:id'), '10')
    bs.set(qn('w:name'), '可溶性岩石')
    be = OxmlElement('w:bookmarkEnd')
    be.set(qn('w:id'), '10')
    runs = target._element.findall(qn('w:r'))
    if runs:
        runs[0].addprevious(bs)
        runs[-1].addnext(be)
    out = os.path.join(RES, '案例1-1_书签.docx')
    doc.save(out)
    return out


def case13_symbol():
    """案例1-3：插入 Wingdings 十进制 83 符号。"""
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = sec.bottom_margin = Pt(72)
    sec.left_margin = sec.right_margin = Pt(72)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    set_run_font(p.add_run('【案例1-3】在下面一段文本后插入符号：'),
                 ascii_font='黑体', ea_font='黑体', size=12, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.line_spacing = 1.5
    set_run_font(p2.add_run('溶洞指的是由雨水或地下水溶解侵蚀石灰岩层所形成的空洞。'),
                 ascii_font='Times New Roman', ea_font='宋体', size=12)
    r = p2.add_run(SYM)
    set_run_font(r, ascii_font='Wingdings', ea_font='Wingdings', size=12)
    out = os.path.join(RES, '案例1-3_插入符号.docx')
    doc.save(out)
    return out


def _ensure_outline(style, lvl):
    pPr = style.element.get_or_add_pPr()
    old = pPr.find(qn('w:outlineLvl'))
    if old is not None:
        pPr.remove(old)
    ol = OxmlElement('w:outlineLvl')
    ol.set(qn('w:val'), str(lvl))
    pPr.append(ol)


def case123_toc():
    """案例1-23：在论文第 1 节空白页创建目录（TOC 域）。"""
    doc = Document('论文原稿 .docx')
    # 标题样式加上大纲级别，目录才能自动收录
    for name, lvl in (('样式1', 0), ('样式2', 1), ('样式3', 2)):
        _ensure_outline(doc.styles[name], lvl)

    ps = doc.paragraphs
    # 定位：第 1 节最后几个空段落（索引 38、39 附近）
    anchor = ps[38]

    # 目录标题
    title = copy.deepcopy(anchor._element)
    for r in title.findall(qn('w:r')):
        title.remove(r)
    anchor._element.addprevious(title)
    from docx.text.paragraph import Paragraph
    tp = Paragraph(title, anchor._parent)
    tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(tp.add_run('目　录'), ascii_font='黑体', ea_font='黑体',
                 size=16, bold=True)

    # TOC 域
    fields = [('begin', None), ('instr', ' TOC \\o "1-3" \\h \\z \\u '),
              ('separate', None), ('text', '（目录域：按 F9 更新后自动生成）'),
              ('end', None)]
    p = anchor
    for kind, val in fields:
        r = OxmlElement('w:r')
        if kind in ('begin', 'separate', 'end'):
            fc = OxmlElement('w:fldChar')
            fc.set(qn('w:fldCharType'), kind)
            r.append(fc)
        elif kind == 'instr':
            it = OxmlElement('w:instrText')
            it.set(qn('xml:space'), 'preserve')
            it.text = val
            r.append(it)
        else:
            t = OxmlElement('w:t')
            t.text = val
            r.append(t)
        p._element.addprevious(r)

    out = os.path.join(RES, '案例1-23_论文目录.docx')
    doc.save(out)
    return out


if __name__ == '__main__':
    print(case11_bookmark())
    print(case13_symbol())
    print(case123_toc())
