import sys, os, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.oxml.ns import qn


def split_run_at(run, pos):
    text = run.text
    new_el = copy.deepcopy(run._element)
    run._element.addnext(new_el)
    from docx.text.run import Run
    new_run = Run(new_el, run._parent)
    run.text = text[:pos]
    new_run.text = text[pos:]
    return run, new_run


def expand_runs(paragraph):
    """One Run object per w:t element, in document order."""
    from docx.text.run import Run
    out = []
    for r_el in paragraph._element.findall(qn('w:r')):
        ts = r_el.findall(qn('w:t'))
        if not ts:
            out.append(Run(r_el, paragraph))
            continue
        first = True
        for t in ts:
            if first:
                out.append(Run(r_el, paragraph))
                first = False
            else:
                nr = copy.deepcopy(r_el)
                for tt in nr.findall(qn('w:t')):
                    nr.remove(tt)
                nt = copy.deepcopy(t)
                nr.append(nt)
                r_el.addnext(nr)
                out.append(Run(nr, paragraph))
            r_el = out[-1]._element
    return out


def wrap_range(paragraph, start, end, name, bid='1'):
    """Wrap characters [start,end) of the paragraph text in a bookmark."""
    runs = expand_runs(paragraph)
    full = ''.join(r.text for r in runs)
    assert full[start:end], (start, end, full[:60])
    pos = 0
    start_el = end_el = None
    for r in runs:
        rlen = len(r.text)
        if start_el is None and pos + rlen >= start:
            off = start - pos
            if off == 0:
                start_el = r._element
            else:
                left, right = split_run_at(r, off)
                start_el = right._element
                rlen = len(right.text)
                pos = start
        if start_el is not None and end_el is None and pos + rlen >= end:
            off = end - pos
            if off == len(r.text):
                end_el = r._element
            else:
                left, right = split_run_at(r, off)
                end_el = left._element
            break
        pos += rlen

    cands = list(paragraph._element.iter(qn('w:r')))
    if start_el is None:
        for r in cands:
            if r.text and r.text.startswith(full[start]):
                start_el = r
                break
    if end_el is None:
        for r in cands:
            if r.text and full[end - 1] in r.text:
                end_el = r
    assert start_el is not None and end_el is not None, full
    bs = paragraph._element.makeelement(qn('w:bookmarkStart'), {})
    bs.set(qn('w:id'), bid)
    bs.set(qn('w:name'), name)
    be = paragraph._element.makeelement(qn('w:bookmarkEnd'), {})
    be.set(qn('w:id'), bid)
    start_el.addprevious(bs)
    end_el.addnext(be)
    return bs, be


if __name__ == '__main__':
    doc = Document('word2.docx')
    p = doc.paragraphs[5]
    wrap_range(p, 8, 8 + 6, '欧罗巴人')
    print(p._element.xml[:600])
