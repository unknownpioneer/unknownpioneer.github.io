from docx import Document
d = Document('word2.docx')
i = 5
t = d.paragraphs[i].text
with open('tools/dbg_scan.txt', 'w', encoding='utf-8') as f:
    f.write('index 5 text: %r\n' % t)
    for key in ('居民是白种人', '居民是白种人，', '居民', '白种人'):
        f.write('%r in text -> %s\n' % (key, key in t))
    f.write('codepoints around: %s\n' % ' '.join('%04X' % ord(c) for c in t[:40]))
    for j, p in enumerate(d.paragraphs):
        f.write('%d len=%d has=%s\n' % (j, len(p.text), '居民是白种人' in p.text))
print('ok')
