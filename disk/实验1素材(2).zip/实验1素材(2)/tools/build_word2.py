"""习题4：打开 word2.docx，参照样文 word2.pdf 设置文本格式（6 项要求）。

输出：结果/习题4_word2_排版完成.docx
"""
import sys, os, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docxhlp import el, set_run_font, add_field, W
from bookmark import wrap_range

SRC = 'word2.docx'
OUT = os.path.join('结果', '习题4_word2_排版完成.docx')

FOOTNOTE_CT = ('application/vnd.openxmlformats-officedocument'
               '.wordprocessingml.footnotes+xml')
FOOTNOTE_RT = ('http://schemas.openxmlformats.org/officeDocument/2006/'
               'relationships/footnotes')


def get_footnotes_part(doc):
    from docx.opc.part import Part
    from docx.opc.packuri import PackURI
    pkg = doc.part.package
    for part in pkg.parts:
        if str(part.partname).endswith('/footnotes.xml'):
            return part
    xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
        '<w:footnotes xmlns:w="%s" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<w:footnote w:type="separator" w:id="-1"><w:p><w:pPr>'
        '<w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>'
        '<w:r><w:separator/></w:r></w:p></w:footnote>'
        '<w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:pPr>'
        '<w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>'
        '<w:r><w:continuationSeparator/></w:r></w:p></w:footnote>'
        '</w:footnotes>' % W)
    part = Part(PackURI('/word/footnotes.xml'), FOOTNOTE_CT,
                xml.encode('utf-8'), pkg)
    doc.part.relate_to(part, FOOTNOTE_RT)
    pkg.parts.append(part)
    return part


def set_track_revisions(doc, on=True):
    settings = doc.settings.element
    existing = settings.find(qn('w:trackRevisions'))
    if on and existing is None:
        settings.insert(0, OxmlElement('w:trackRevisions'))
    elif not on and existing is not None:
        settings.remove(existing)


def insert_footnote_ref(paragraph, after_text, fid):
    """Insert a footnote reference run right after `after_text`."""
    runs = paragraph.runs
    for r in runs:
        if after_text in r.text:
            pos = r.text.index(after_text) + len(after_text)
            new_el = copy.deepcopy(r._element)
            r._element.addnext(new_el)
            from docx.text.run import Run
            new_run = Run(new_el, paragraph)
            orig = r.text
            r.text = orig[:pos]
            new_run.text = orig[pos:]
            ref_run = OxmlElement('w:r')
            rPr = OxmlElement('w:rPr')
            rs = OxmlElement('w:rStyle')
            rs.set(qn('w:val'), 'FootnoteReference')
            rPr.append(rs)
            ref_run.append(rPr)
            ref = OxmlElement('w:footnoteReference')
            ref.set(qn('w:id'), str(fid))
            ref_run.append(ref)
            new_el.addprevious(ref_run)
            return True
    return False


def mark_deleted_text(run, author='学生', date='2026-10-13T00:00:00Z',
                      rid='901'):
    r = run._element
    text = run.text
    for t in r.findall(qn('w:t')):
        r.remove(t)
    # 清理从原 run 复制来的 rsid（w:del 上不允许出现）
    for attr in list(r.attrib):
        if attr.startswith('{http://schemas.openxmlformats.org/wordprocessingml'
                           '/2006/main}rsid'):
            del r.attrib[attr]
    dt = OxmlElement('w:delText')
    dt.set(qn('xml:space'), 'preserve')
    dt.text = text
    r.append(dt)
    parent = r.getparent()
    idx = list(parent).index(r)
    dele = OxmlElement('w:del')
    dele.set(qn('w:id'), rid)
    dele.set(qn('w:author'), author)
    dele.set(qn('w:date'), date)
    parent.remove(r)
    parent.insert(idx, dele)
    dele.append(r)
    return dele


def make_footnote_xml(fid, text):
    return (
        '<w:footnote xmlns:w="%s" w:id="%d">'
        '<w:p><w:pPr><w:pStyle w:val="FootnoteText"/></w:pPr>'
        '<w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr>'
        '<w:footnoteRef/></w:r>'
        '<w:r><w:t xml:space="preserve"> %s</w:t></w:r>'
        '</w:p></w:footnote>' % (W, fid, text))


def add_drop_cap(paragraph, lines=3, font='楷体', sz_half_pt=88):
    """Turn the paragraph's first character into a real Word drop cap."""
    if not paragraph.runs:
        paragraph.add_run('')
    first = paragraph.runs[0]
    first_char, rest = first.text[0], first.text[1:]
    first.text = rest

    frame_p = OxmlElement('w:p')
    pPr = OxmlElement('w:pPr')
    framePr = OxmlElement('w:framePr')
    framePr.set(qn('w:dropCap'), 'drop')
    framePr.set(qn('w:lines'), str(lines))
    framePr.set(qn('w:wrap'), 'around')
    framePr.set(qn('w:vAnchor'), 'text')
    framePr.set(qn('w:hAnchor'), 'text')
    pPr.append(framePr)
    rPr_p = OxmlElement('w:rPr')
    rf = OxmlElement('w:rFonts')
    rf.set(qn('w:ascii'), font)
    rf.set(qn('w:hAnsi'), font)
    rf.set(qn('w:eastAsia'), font)
    rPr_p.append(rf)
    sz = OxmlElement('w:sz')
    sz.set(qn('w:val'), str(sz_half_pt))
    rPr_p.append(sz)
    pPr.append(rPr_p)
    frame_p.append(pPr)

    r = OxmlElement('w:r')
    rPr = OxmlElement('w:rPr')
    rf2 = OxmlElement('w:rFonts')
    rf2.set(qn('w:ascii'), font)
    rf2.set(qn('w:hAnsi'), font)
    rf2.set(qn('w:eastAsia'), font)
    rPr.append(rf2)
    sz2 = OxmlElement('w:sz')
    sz2.set(qn('w:val'), str(sz_half_pt))
    rPr.append(sz2)
    r.append(rPr)
    t = OxmlElement('w:t')
    t.text = first_char
    r.append(t)
    frame_p.append(r)
    paragraph._element.addprevious(frame_p)
    paragraph.paragraph_format.line_spacing = 1.0


def main():
    os.makedirs('结果', exist_ok=True)
    doc = Document(SRC)
    # paragraphs[0] 是标题；正文段落从 paragraphs[1] 起算
    body_ps = [p for p in doc.paragraphs[1:] if p.text.strip()]
    assert len(body_ps) >= 6, [p.text[:20] for p in body_ps]

    # ---------- ① 正文第 1 段"欧洲"后插入脚注：历史悠久 ----------
    from lxml import etree
    fp = get_footnotes_part(doc)
    froot = etree.fromstring(fp.blob)
    ids = [int(f.get(qn('w:id'))) for f in froot.findall(qn('w:footnote'))]
    fid = max(ids) + 1
    froot.append(etree.fromstring(make_footnote_xml(fid, '历史悠久')))
    fp._blob = etree.tostring(froot, xml_declaration=True,
                              encoding='UTF-8', standalone=True)
    assert insert_footnote_ref(body_ps[0], '欧洲', fid), '脚注插入位置未找到'

    # ---------- ② 正文第 5 段"居民是白种人"插入书签：欧罗巴人 ----------
    p5 = body_ps[4] if '居民是白种人' in body_ps[4].text else None
    if p5 is None:
        for cand in body_ps:
            if '居民是白种人' in cand.text:
                p5 = cand
                break
    assert p5 is not None, '未找到含"居民是白种人"的段落'
    p5_text = p5.text
    start = p5_text.index('居民是白种人')
    wrap_range(p5, start, start + len('居民是白种人'), '欧罗巴人')

    # ---------- ③ 正文第 3 段字符数（不计空格）写入页眉中间 ----------
    t3 = body_ps[2].text
    count3 = len(t3.replace(' ', '').replace('\u3000', ''))
    hdr = doc.sections[0].header
    hdr.is_linked_to_previous = False
    hp = hdr.paragraphs[0]
    hp.alignment = 1
    add_field(hp, ' PAGE ', placeholder='1',
              font='Times New Roman', ea='宋体', size=10.5)
    rr = hp.add_run('  第3段字符数（不计空格）：%d' % count3)
    set_run_font(rr, ascii_font='Times New Roman', ea_font='宋体', size=10.5)

    # ---------- ④ 正文第 3 段首字下沉 ----------
    add_drop_cap(body_ps[2], lines=3, font='楷体', sz_half_pt=88)

    # ---------- ⑤ 打开修订功能，删除正文最后 1 段 ----------
    set_track_revisions(doc, True)
    for r in list(body_ps[-1].runs):
        if r.text:
            mark_deleted_text(r)

    doc.save(OUT)
    print('saved:', OUT)
    print('第3段字符数(不计空格) =', count3)


if __name__ == '__main__':
    main()
