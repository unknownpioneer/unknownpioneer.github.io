import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream, build_fonts

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
fm = build_fonts(objs)
print('built fonts:', {k: (v[0], len(v[1])) for k, v in fm.items()})

sd = get_stream(objs[52]).decode('latin1')
print('fonts used:', sorted(set(re.findall(r'/([A-Za-z0-9]+)\s+[\d.]+\s+Tf', sd))))
print(sd[1500:4000])
