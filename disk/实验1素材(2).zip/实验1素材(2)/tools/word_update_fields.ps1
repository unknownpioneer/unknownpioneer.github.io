# 用 Word COM 打开文档并更新所有域（目录/题注/页码），然后保存
$ErrorActionPreference = 'Stop'
$files = @(
  '结果\习题1_论文原稿_排版完成.docx',
  '结果\习题4_word2_排版完成.docx',
  '结果\案例1-23_论文目录.docx',
  '结果\案例1-1_书签.docx',
  '结果\案例1-3_插入符号.docx'
)
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
$base = (Get-Location).Path
foreach ($rel in $files) {
  $full = Join-Path $base $rel
  if (-not (Test-Path $full)) { Write-Host "MISSING $rel"; continue }
  $doc = $word.Documents.Open($full, $false, $false)
  try {
    # 更新所有域（含 TOC）
    $doc.Fields.Update() | Out-Null
    foreach ($sec in $doc.Sections) {
      foreach ($h in $sec.Headers) { foreach ($f in $h.Range.Fields) { $f.Update() | Out-Null } }
      foreach ($f in $sec.Footers) { foreach ($ff in $f.Range.Fields) { $ff.Update() | Out-Null } }
    }
    if ($doc.TablesOfContents.Count -gt 0) {
      for ($i = 1; $i -le $doc.TablesOfContents.Count; $i++) { $doc.TablesOfContents.Item($i).Update() }
    }
    $doc.Save()
    Write-Host ("UPDATED " + $rel + " (toc=" + $doc.TablesOfContents.Count + ", pages=" + $doc.ComputeStatistics(2) + ")")
  } finally {
    $doc.Close($true)
  }
}
$word.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
Write-Host "DONE"
