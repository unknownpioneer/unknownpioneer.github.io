from docx import Document
d = Document('word1.docx')
with open('tools/plist.txt', 'w', encoding='utf-8') as f:
    for i, p in enumerate(d.paragraphs):
        t = p.text
        f.write('%d len=%d chars_nospace=%d | %s\n' % (
            i, len(t), len(t.replace(' ', '').replace('\u3000', '')), t[:30]))
print('ok')
