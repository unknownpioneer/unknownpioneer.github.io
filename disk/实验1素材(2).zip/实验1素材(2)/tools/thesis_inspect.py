import sys
from docx import Document
from docx.oxml.ns import qn

path = r'论文原稿 .docx'
out = 'tools/thesis_struct.txt'
doc = Document(path)
f = open(out, 'w', encoding='utf-8')

f.write('sections: %d\n' % len(doc.sections))
for si, s in enumerate(doc.sections):
    f.write('  sec%d start=%s w=%.1f h=%.1f top=%.2f bottom=%.2f left=%.2f right=%.2f cols=%s\n' % (
        si, s.start_type, s.page_width.cm, s.page_height.cm,
        s.top_margin.cm, s.bottom_margin.cm, s.left_margin.cm, s.right_margin.cm,
        len(s._sectPr.findall(qn('w:cols')))))
    hdr = s.header
    f.write('      header linked=%s text=%r\n' % (
        hdr.is_linked_to_previous, [p.text for p in hdr.paragraphs]))
    ftr = s.footer
    f.write('      footer linked=%s text=%r\n' % (
        ftr.is_linked_to_previous, [p.text for p in ftr.paragraphs]))

f.write('\n--- STYLES (used) ---\n')
used = set()
for p in doc.paragraphs:
    used.add(p.style.name)
for name in sorted(used):
    try:
        st = doc.styles[name]
    except KeyError:
        f.write('%s MISSING\n' % name)
        continue
    fo = st.font
    pf = st.paragraph_format
    ea = None
    if st.element.rPr is not None and st.element.rPr.rFonts is not None:
        ea = st.element.rPr.rFonts.get(qn('w:eastAsia'))
    f.write('%-16s font=%s ea=%s size=%s bold=%s align=%s sb=%s sa=%s ls=%s base=%s\n' % (
        name, fo.name, ea, fo.size.pt if fo.size else None, fo.bold,
        pf.alignment, pf.space_before, pf.space_after, pf.line_spacing,
        st.base_style.name if st.base_style else None))

f.write('\n--- PARAGRAPHS ---\n')
for i, p in enumerate(doc.paragraphs):
    pf = p.paragraph_format
    t = p.text
    numpr = p._element.find(qn('w:pPr'))
    numinfo = ''
    if numpr is not None:
        np = numpr.find(qn('w:numPr'))
        if np is not None:
            numinfo = ' numPr=' + np.xml.replace('xmlns:w="%s"' % qn('w:x'), '')[:120]
    f.write('[%d] style=%s align=%s indent=%.2f/%.2f sb=%s sa=%s ls=%s%s\n' % (
        i, p.style.name, pf.alignment,
        (pf.left_indent.pt if pf.left_indent else 0),
        (pf.first_line_indent.pt if pf.first_line_indent else 0),
        pf.space_before.pt if pf.space_before else None,
        pf.space_after.pt if pf.space_after else None,
        pf.line_spacing, numinfo))
    f.write('     %r\n' % t[:160])
    for r in p.runs[:3]:
        if not r.text.strip():
            continue
        ea = None
        if r._element.rPr is not None and r._element.rPr.rFonts is not None:
            ea = r._element.rPr.rFonts.get(qn('w:eastAsia'))
        f.write('     RUN %r ascii=%s ea=%s sz=%s b=%s i=%s u=%s\n' % (
            r.text[:20], r.font.name, ea,
            r.font.size.pt if r.font.size else None,
            r.font.bold, r.font.italic, r.font.underline))

f.write('\n--- TABLES ---\n')
for ti, t in enumerate(doc.tables):
    f.write('table %d: %dx%d\n' % (ti, len(t.rows), len(t.columns)))
f.close()
print('written', out)
