"""把 docx 的段落/表格渲染成 PNG 图片（用于实验报告插图）。

说明：这不是 Word 的屏幕截图，而是按文档的字体、字号、对齐、颜色等属性
重绘的"文档结果预览图"，用于在报告中直观呈现排版结果。
"""
import os, sys, io
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt

FONT_DIR = os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts')
FONT_FILES = {
    '宋体': 'simsun.ttc',
    '黑体': 'simhei.ttf',
    '楷体': 'simkai.ttf',
    '隶书': 'SIMLI.TTF',
    '微软雅黑': 'msyh.ttc',
    'Times New Roman': 'times.ttf',
    'Wingdings': 'wingding.ttf',
}

# 纸张与页边距（像素，按 96 dpi 折算：1 cm ≈ 37.8 px）
CM = 37.795
PAGE_W = int(21.0 * CM)
MARGIN_L = int(3.17 * CM)
MARGIN_R = int(3.17 * CM)


def font_path(name):
    f = FONT_FILES.get(name)
    if f:
        p = os.path.join(FONT_DIR, f)
        if os.path.exists(p):
            return p
    return os.path.join(FONT_DIR, 'simsun.ttc')


_cache = {}


def get_font(name, size_pt, bold=False):
    size = max(8, int(round(size_pt * 96 / 72)))
    key = (name, size, bold)
    if key in _cache:
        return _cache[key]
    path = font_path(name)
    try:
        f = ImageFont.truetype(path, size)
    except Exception:
        f = ImageFont.load_default()
    _cache[key] = f
    return f


def run_props(run):
    """返回 (中文字体, 西文字体, 字号, 加粗, 颜色, 下划线, 底纹)。"""
    rPr = run._element.rPr
    ea = ascii_f = None
    if rPr is not None and rPr.rFonts is not None:
        ea = rPr.rFonts.get(qn('w:eastAsia'))
        ascii_f = rPr.rFonts.get(qn('w:ascii'))
    size = run.font.size.pt if run.font.size else None
    bold = bool(run.font.bold)
    color = None
    if run.font.color is not None and run.font.color.type is not None:
        try:
            color = run.font.color.rgb
        except Exception:
            color = None
    underline = None
    if rPr is not None:
        u = rPr.find(qn('w:u'))
        if u is not None and u.get(qn('w:val')) not in (None, 'none'):
            underline = (u.get(qn('w:val')), u.get(qn('w:color')))
    shading = None
    if rPr is not None:
        shd = rPr.find(qn('w:shd'))
        if shd is not None:
            shading = shd.get(qn('w:fill'))
    return ea or '宋体', ascii_f or 'Times New Roman', size, bold, color, underline, shading


def wrap_runs(runs, max_width, default_size=10.5):
    """把 [(text, font, color, underline, shading, size)] 贪心折行。"""
    lines, cur, cur_w = [], [], 0
    for text, fnt, color, ul, shd, size in runs:
        for ch in text:
            w = fnt.getlength(ch)
            if cur_w + w > max_width and cur:
                lines.append((cur, cur_w))
                cur, cur_w = [], 0
            cur.append((ch, fnt, color, ul, shd, size))
            cur_w += w
    if cur:
        lines.append((cur, cur_w))
    return lines


def render_docx(path, out_png, max_height_px=1150, start_par=0,
                end_par=None, bg='FFFFFF'):
    doc = Document(path)
    paras = doc.paragraphs
    # 先在虚拟画布上排,再裁切
    W = PAGE_W
    content_w = W - MARGIN_L - MARGIN_R
    rows = []   # (height, kind, payload)
    y = 40

    for pi, p in enumerate(paras):
        if pi < start_par:
            continue
        if end_par is not None and pi >= end_par:
            break
        pf = p.paragraph_format
        # 段落行高
        has_runs = [r for r in p.runs if r.text]
        if not has_runs:
            rows.append((14, 'gap', None))
            y += 14
            continue
        specs = []
        for r in has_runs:
            ea, af, size, bold, color, ul, shd = run_props(r)
            sz = size or (runs_prev_size if False else 10.5)
            fnt = get_font(ea, sz, bold)
            specs.append((r.text, fnt, color, ul, shd, sz))
        lines = wrap_runs(specs, content_w)
        align = pf.alignment
        left = MARGIN_L
        if pf.first_line_indent and pf.first_line_indent.pt:
            left += int(pf.first_line_indent.pt * 96 / 72)
        for li, (chars, wpx) in enumerate(lines):
            lh = int(max((s[5] for s in chars), default=10.5) * 1.55 * 96 / 72)
            if align is not None and int(align) == 1:      # 居中
                x0 = MARGIN_L + max(0, (content_w - wpx) // 2)
            elif align is not None and int(align) == 2:    # 右对齐
                x0 = W - MARGIN_R - wpx
            else:
                x0 = left
            rows.append((lh, 'line', (chars, x0, lh)))
            y += lh
        sb = pf.space_before.pt if pf.space_before else 0
        if sb:
            rows.append((int(sb * 96 / 72), 'gap', None))
            y += int(sb * 96 / 72)
        y += 3

    H = min(max_height_px, max(200, y + 40))
    img = Image.new('RGB', (W, H), '#' + bg)
    d = ImageDraw.Draw(img)
    y = 30
    for height, kind, payload in rows:
        if y > H:
            break
        if kind == 'gap':
            y += height
            continue
        chars, x0, lh = payload
        x = x0
        for ch, fnt, color, ul, shd, _sz in chars:
            cw = fnt.getlength(ch)
            if shd and shd not in ('auto', 'FFFFFF'):
                d.rectangle([x, y + 2, x + cw, y + lh - 2], fill='#' + shd)
            fill = ('#' + str(color)) if color else '#000000'
            try:
                d.text((x, y), ch, font=fnt, fill=fill)
            except Exception:
                pass
            if ul:
                uy = y + lh - 6
                d.line([x, uy, x + cw, uy], fill=fill, width=2)
                if ul[0] == 'double':
                    d.line([x, uy + 3, x + cw, uy + 3], fill=fill, width=1)
            x += cw
        y += lh

    # 加上细边框，看起来像一页文档
    d.rectangle([0, 0, W - 1, H - 1], outline='#BBBBBB')
    img.save(out_png)
    return out_png


def render_plain(lines, out_png, title=None, width=900, bg='FFFFFF',
                 title_color='#1F4E79', body_size=13, pad=26):
    """渲染纯文本卡片（用于"提示词/输出"等文字类图）。"""
    f_body = get_font('宋体', body_size)
    f_title = get_font('黑体', body_size + 4, True)
    maxw = width - 2 * pad
    wrapped = []
    for ln in lines:
        cur = ''
        for ch in ln:
            if f_body.getlength(cur + ch) > maxw:
                wrapped.append(cur)
                cur = ch
            else:
                cur += ch
        wrapped.append(cur)
    lh = int(body_size * 1.75 * 96 / 72)
    head = (int(body_size * 2.4 * 96 / 72) + 14) if title else 0
    H = head + lh * len(wrapped) + 2 * pad
    img = Image.new('RGB', (width, H), '#' + bg)
    d = ImageDraw.Draw(img)
    y = pad
    if title:
        d.text((pad, y), title, font=f_title, fill=title_color)
        y += int(body_size * 2.4 * 96 / 72) + 6
    for ln in wrapped:
        d.text((pad, y), ln, font=f_body, fill='#111111')
        y += lh
    d.rectangle([0, 0, width - 1, H - 1], outline='#BBBBBB')
    img.save(out_png)
    return out_png


if __name__ == '__main__':
    src = sys.argv[1]
    dst = sys.argv[2]
    render_docx(src, dst)
    print('rendered', dst)
