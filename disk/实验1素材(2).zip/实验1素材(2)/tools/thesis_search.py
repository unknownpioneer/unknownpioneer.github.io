import sys
from docx import Document
d = Document(r'论文原稿 .docx')
with open('tools/thesis_search.txt', 'w', encoding='utf-8') as f:
    for i, p in enumerate(d.paragraphs[:40]):
        f.write('[%d] style=%s align=%s sb=%s sa=%s ls=%s | %r\n' % (
            i, p.style.name, p.paragraph_format.alignment,
            p.paragraph_format.space_before.pt if p.paragraph_format.space_before else None,
            p.paragraph_format.space_after.pt if p.paragraph_format.space_after else None,
            p.paragraph_format.line_spacing, p.text))
    f.write('\n--- style ids ---\n')
    for name in ('样式1', '样式2', '样式3'):
        st = d.styles[name]
        f.write('%s -> styleId=%s outlineLvlAttr=%s\n' % (
            name, st.style_id,
            'yes' if st.element.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}pPr') is not None else 'no'))
print('ok')
