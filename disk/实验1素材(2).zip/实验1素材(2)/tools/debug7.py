import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream, parse_tounicode

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
for n in (623, 613, 617):
    sd = get_stream(objs[n])
    if sd is None:
        print('obj', n, 'no stream'); continue
    cm = parse_tounicode(sd)
    ks = sorted(cm)
    print('obj', n, 'entries', len(cm))
    for k in ks[:8]:
        print('   ', hex(k), hex(ord(cm[k])), repr(cm[k]))
