import sys, re
sys.path.insert(0, 'tools')
from pdftext import load, get_stream, parse_tounicode, build_fonts, extract_page, page_objects

d, objs = load(r'实验01_文字信息处理+AI辅助工具使用(2).pdf')
for n in (499, 494, 496, 623, 613, 617):
    print('== obj', n, 'len', len(objs.get(n, b'')), repr(objs.get(n, b'')[:120]))
sd = get_stream(objs[623])
print('get_stream(623) len', len(sd) if sd else None)
if sd:
    print(sd[:200])
    print('entries', len(parse_tounicode(sd)))
fm = build_fonts(objs)
print('font 494 entries', len(fm[494][1]), 'font 499 entries', len(fm[499][1]))
print(sorted(fm[499][1].items())[:10])
print('sample 048F->', fm[499][1].get(0x048F))
