"""练习题2：制作一份自己申请参加社团所需的个人简历。

要求：内容完整、全面介绍自己各方面信息和特长，表达真实恰当，
      在构思、版面设计上有新意、有创新、有个性。

输出：结果/习题2_社团申请个人简历.docx
"""
import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = os.path.join('结果', '习题2_社团申请个人简历.docx')
IMG = '简历封面图形.jpg'

NAVY = '1F4E79'
ACCENT = 'C00000'
GREY = '595959'


def set_cell_bg(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), color)
    tcPr.append(shd)


def run_font(run, name='宋体', size=10.5, bold=False, color=None, italic=False):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rPr = run._element.get_or_add_rPr()
    rf = rPr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts')
        rPr.insert(0, rf)
    rf.set(qn('w:ascii'), 'Times New Roman')
    rf.set(qn('w:hAnsi'), 'Times New Roman')
    rf.set(qn('w:eastAsia'), name)


def para(doc, text='', size=10.5, name='宋体', bold=False, color=None,
         align=None, before=0, after=4, indent=None, line=1.15):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line
    if align is not None:
        pf.alignment = align
    if indent is not None:
        pf.left_indent = Pt(indent)
    if text:
        run_font(p.add_run(text), name, size, bold, color)
    return p


def section_title(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(10)
    pf.space_after = Pt(4)
    run_font(p.add_run('■ ' + text), '黑体', 12, True, NAVY)
    # 下边框
    pPr = p._element.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '8')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), NAVY)
    pbdr.append(bottom)
    pPr.append(pbdr)
    return p


def bullet(doc, text, bold_prefix=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Pt(24)
    pf.first_line_indent = Pt(-12)
    pf.space_after = Pt(2)
    pf.line_spacing = 1.15
    run_font(p.add_run('◆ '), '宋体', 9, False, ACCENT)
    if bold_prefix:
        run_font(p.add_run(bold_prefix), '宋体', 10.5, True)
    run_font(p.add_run(text), '宋体', 10.5)
    return p


def main():
    os.makedirs('结果', exist_ok=True)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2)
    sec.right_margin = Cm(2.2)

    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    # ---------------- 封面头部 ----------------
    if os.path.exists(IMG):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(IMG, width=Cm(3.6))

    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.paragraph_format.space_after = Pt(0)
    run_font(t.add_run('个 人 简 历'), '黑体', 26, True, NAVY)

    st = doc.add_paragraph()
    st.alignment = WD_ALIGN_PARAGRAPH.CENTER
    st.paragraph_format.space_after = Pt(8)
    run_font(st.add_run('—— 校「绿野」户外运动协会招新申请 ——'), '楷体', 12, False, GREY)

    # ---------------- 基本信息表 ----------------
    info = [
        ('姓　　名', '马腾飞', '性　　别', '男'),
        ('出生日期', '1993-10-01', '政治面貌', '共青团员'),
        ('学　　院', '计算机与软件学院', '专　　业', '计算机科学与技术'),
        ('联系电话', '12345678912', '电子邮箱', 'matengfei@126.com'),
        ('申请社团', '校「绿野」户外运动协会', '申请岗位', '技术宣传部'),
    ]
    tb = doc.add_table(rows=len(info), cols=4)
    tb.style = 'Table Grid'
    tb.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(info):
        for j, val in enumerate(row):
            cell = tb.cell(i, j)
            cell.text = ''
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            label = (j % 2 == 0)
            run_font(p.add_run(val), '宋体', 10.5, label,
                     NAVY if label else None)
            if label:
                set_cell_bg(cell, 'DCE6F1')

    # ---------------- 教育背景 ----------------
    section_title(doc, '教育背景')
    bullet(doc, '2011.09—2015.06　深圳大学　计算机与软件学院　计算机科学与技术（本科）',
           bold_prefix='')
    bullet(doc, '主修课程：程序设计基础、数据结构、数据库原理、计算机网络、Android 应用开发、软件工程。')
    bullet(doc, '成绩情况：连续三年获校级奖学金，专业排名前 15%；英语六级（CET-6）。')

    # ---------------- 技能特长 ----------------
    section_title(doc, '技能与特长')
    bullet(doc, '熟悉 Java / Android 开发，能独立完成 App 界面与本地数据库（SQLite）的开发；',
           bold_prefix='技术能力：')
    bullet(doc, '熟悉 HTML / CSS / JavaScript，能完成社团活动海报与宣传页面的制作；',
           bold_prefix='')
    bullet(doc, '熟练使用 Photoshop、Premiere，可承担活动摄影、视频剪辑与新媒体推文排版；',
           bold_prefix='')
    bullet(doc, '持红十字救护员证，掌握基础户外急救与野外生存技能；',
           bold_prefix='')
    bullet(doc, '四百米、三千米长跑为个人强项，校运动会 3000 米第 2 名。',
           bold_prefix='')

    # ---------------- 社团与实践经历 ----------------
    section_title(doc, '社团与实践经历')
    bullet(doc, '2012.09—2014.06　校计算机协会　技术部部长：负责协会网站的搭建与维护，'
                '组织 6 场技术分享会，会员规模由 60 人增至 150 人；', bold_prefix='')
    bullet(doc, '2013.07—2013.08　暑期“三下乡”社会实践队　宣传组成员：拍摄并剪辑纪录片'
                '《山那边的课堂》，获校级优秀实践团队；', bold_prefix='')
    bullet(doc, '2014.03　深圳百公里徒步活动　志愿者：负责签到与补给点服务，连续服务 14 小时；',
           bold_prefix='')
    bullet(doc, '2014.12—2015.07　深圳腾讯公司　软件开发实习生：参与后台模块开发与测试。',
           bold_prefix='')

    # ---------------- 获奖情况 ----------------
    section_title(doc, '获奖情况')
    bullet(doc, '2012—2013 学年第二学期　三等奖学金；', bold_prefix='')
    bullet(doc, '2013—2014 学年第一学期　一等奖学金；', bold_prefix='')
    bullet(doc, '2013 年　广东省“挑战杯”大学生课外学术科技作品竞赛　三等奖；', bold_prefix='')
    bullet(doc, '2014 年　广东省“挑战杯”大学生课外学术科技作品竞赛　二等奖。', bold_prefix='')

    # ---------------- 自我评价与申请理由 ----------------
    section_title(doc, '自我评价与申请理由')
    para(doc, '我性格开朗、乐于协作，做事踏实、有耐心，喜欢在户外运动中挑战自我。'
              '三年来我坚持每周三次晨跑，并利用假期完成了深圳百公里徒步与两次山地露营，'
              '具备良好的体能和团队意识。我希望加入「绿野」户外运动协会的技术宣传部，'
              '用所学的开发与设计能力为协会搭建报名系统、维护公众号，'
              '把协会的活动记录拍得更好看、传播得更远。我相信技术与热爱的结合，'
              '能让更多人走进山野、爱上运动。',
         size=10.5, indent=24, line=1.3, after=6)

    # ---------------- 页脚签名 ----------------
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_before = Pt(16)
    run_font(p.add_run('申请人：马腾飞　　　　　'), '宋体', 10.5)
    run_font(p.add_run('2026 年 10 月 13 日'), '宋体', 10.5)

    doc.save(OUT)
    print('saved:', OUT)


if __name__ == '__main__':
    main()
