"""习题1：继续完成毕业论文的其他部分排版（7 项要求）。

要求：
  ① 论文的西文字体采用 Times New Roman
  ② 正文内容五号宋体；段前段后 0.5 行、两端对齐
  ③ 标题：主标题小二号华文中宋加粗；副标题小四号宋体；1.5 倍行距居中
  ④ 摘要与关键词：【】内小四号楷体加粗，【】外五号楷体
  ⑤ 参考文献：【】标题五号楷体顶格加粗，内容小五号楷体顶格
  ⑥ 摘要、正文、参考文献一律单倍行距、段前段后 0.5 行、两端对齐
  ⑦ 设置页眉页脚，内容见样文

输出：结果/习题1_论文原稿_排版完成.docx
"""
import sys, os, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docxhlp import set_run_font

SRC = '论文原稿 .docx'
OUT = os.path.join('结果', '习题1_论文原稿_排版完成.docx')

WESTERN = 'Times New Roman'
SONG = '宋体'
KAITI = '楷体'
HEITI = '黑体'

SZ_ER = 22.0     # 二号
SZ_XIAO_ER = 18.0  # 小二号
SZ_SAN = 16.0
SZ_XIAO_SAN = 15.0
SZ_SI = 14.0
SZ_XIAO_SI = 12.0
SZ_WU = 10.5
SZ_XIAO_WU = 9.0

HALF_LINE = 6.0    # 0.5 行 ≈ 6 磅（五号 12 磅行高的 0.5 倍）


def fmt_para(p, align=None, line=None, before=None, after=None,
             first_line_chars=None, clear_first_line=False):
    pf = p.paragraph_format
    if align is not None:
        pf.alignment = align
    if line is not None:
        pf.line_spacing = line
        pf.line_spacing_rule = WD_LINE_SPACING.SINGLE if line == 1.0 else None
    if before is not None:
        pf.space_before = Pt(before)
    if after is not None:
        pf.space_after = Pt(after)
    pPr = p._element.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is not None:
        for a in ('w:firstLineChars', 'w:firstLine', 'w:hangingChars', 'w:hanging'):
            if a in ind.attrib:
                del ind.attrib[a]
    return p


def fmt_runs(p, ascii_font=None, ea_font=None, size=None, bold=None):
    for r in p.runs:
        set_run_font(r, ascii_font=ascii_font, ea_font=ea_font,
                     size=size, bold=bold)


def is_body_paragraph(p):
    """正文段落：普通正文内容段（排除标题/题注/参考文献/封面）。"""
    if not p.text.strip():
        return False
    st = p.style.name
    if st in ('Caption', 'toc 1', 'endnote text', 'Header', 'Footer'):
        return False
    if st.startswith('样式') or st.startswith('标题'):
        return False
    return True


def main():
    os.makedirs('结果', exist_ok=True)
    doc = Document(SRC)
    ps = doc.paragraphs

    # ------------------------------------------------------------------
    # ① 全文西文字体 Times New Roman
    # ------------------------------------------------------------------
    for p in ps:
        for r in p.runs:
            rPr = r._element.get_or_add_rPr()
            rf = rPr.find(qn('w:rFonts'))
            if rf is None:
                rf = rPr.makeelement(qn('w:rFonts'), {})
                rPr.insert(0, rf)
            rf.set(qn('w:ascii'), WESTERN)
            rf.set(qn('w:hAnsi'), WESTERN)

    # ------------------------------------------------------------------
    # ② 正文：五号宋体；段前段后 0.5 行；两端对齐
    # ------------------------------------------------------------------
    for p in ps:
        if not is_body_paragraph(p):
            continue
        fmt_runs(p, ea_font=SONG, size=SZ_WU, bold=None)
        fmt_para(p, align=WD_ALIGN_PARAGRAPH.JUSTIFY, line=1.0,
                 before=HALF_LINE, after=HALF_LINE)

    # ------------------------------------------------------------------
    # ③ 标题
    # ------------------------------------------------------------------
    # 主标题：小二号华文中宋加粗（论文题目所在段落）
    main_title_idx = None
    for i, p in enumerate(ps):
        if p.text.strip() == '基于Android的步行者运动软件开发' and i > 20:
            main_title_idx = i
            break
    if main_title_idx is not None:
        p = ps[main_title_idx]
        fmt_para(p, align=WD_ALIGN_PARAGRAPH.CENTER, line=1.5)
        fmt_runs(p, ascii_font='华文中宋', ea_font='华文中宋',
                 size=SZ_XIAO_ER, bold=True)

    # 副标题：小四号宋体，1.5 倍行距居中（学院/学号两行）
    for i in range(main_title_idx + 1 if main_title_idx else 0,
                   min((main_title_idx or 0) + 4, len(ps))):
        t = ps[i].text.strip()
        if not t:
            continue
        if t.startswith('【'):
            break
        fmt_para(ps[i], align=WD_ALIGN_PARAGRAPH.CENTER, line=1.5)
        fmt_runs(ps[i], ea_font=SONG, size=SZ_XIAO_SI)

    # 各级标题：黑体加粗 + 单倍行距 + 段前段后 0.5 行
    for p in ps:
        st = p.style.name
        if st in ('样式1', '标题 1', 'Heading 1'):
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_SAN, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)
        elif st in ('样式2', '标题 2', 'Heading 2'):
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_XIAO_SAN, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)
        elif st in ('样式3', '标题 3', 'Heading 3'):
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_SI, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)

    # 未套用样式但明显是标题的段落（功能模块的实现 / 功能模块 / 结束语）
    for i, p in enumerate(ps):
        t = p.text.strip()
        if p.style.name == 'Normal' and t == '功能模块的实现':
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_XIAO_SAN, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)
            p.style = doc.styles['样式2']
        elif p.style.name == 'Normal' and t in ('结束语',):
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_SAN, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)
            p.style = doc.styles['样式1']
        elif p.style.name == 'Normal' and t in ('登录模块', '注册模块', '左菜单模块',
                                                '运动模块', '地图模块', '排行榜模块',
                                                '手机数据库模块', '计时器模块'):
            fmt_runs(p, ascii_font=HEITI, ea_font=HEITI, size=SZ_SI, bold=True)
            fmt_para(p, line=1.0, before=HALF_LINE, after=HALF_LINE)
            p.style = doc.styles['样式3']

    # ------------------------------------------------------------------
    # ④ 摘要与关键词：【】内小四号楷体加粗，【】外五号楷体
    # ------------------------------------------------------------------
    for p in ps:
        t = p.text.strip()
        if not (t.startswith('【摘要】') or t.startswith('【关键词】')):
            continue
        import re
        from docx.text.run import Run
        # 清空并按【】内外重组 run
        parent = p._element
        for r in list(p.runs):
            parent.remove(r._element)

        def add(text, bold):
            r = p.add_run(text)
            set_run_font(r, ascii_font=WESTERN, ea_font=KAITI,
                         size=SZ_XIAO_SI if bold else SZ_WU, bold=bold)
            return r

        for m in re.finditer(r'【(.*?)】|([^【】]+)', t):
            if m.group(1) is not None:
                add('【' + m.group(1) + '】', True)
            else:
                add(m.group(2), False)
        fmt_para(p, align=WD_ALIGN_PARAGRAPH.JUSTIFY, line=1.0,
                 before=HALF_LINE, after=HALF_LINE)

    # ------------------------------------------------------------------
    # ⑤ 参考文献：【】标题五号楷体顶格加粗，内容小五号楷体顶格
    # ------------------------------------------------------------------
    in_refs = False
    for p in ps:
        t = p.text.strip()
        if t.startswith('【参考文献】'):
            in_refs = True
            for r in p.runs:
                set_run_font(r, ascii_font=WESTERN, ea_font=KAITI,
                             size=SZ_WU, bold=True)
            fmt_para(p, align=WD_ALIGN_PARAGRAPH.LEFT, line=1.0,
                     before=HALF_LINE, after=HALF_LINE,
                     clear_first_line=True)
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.left_indent = Pt(0)
            continue
        if in_refs:
            if not t:
                continue
            if t.startswith('致谢'):
                break
            for r in p.runs:
                set_run_font(r, ascii_font=WESTERN, ea_font=KAITI,
                             size=SZ_XIAO_WU)
            fmt_para(p, align=WD_ALIGN_PARAGRAPH.LEFT, line=1.0,
                     before=HALF_LINE, after=HALF_LINE)
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.left_indent = Pt(0)

    # ------------------------------------------------------------------
    # ⑥ 摘要、正文、参考文献：单倍行距、段前段后 0.5 行、两端对齐
    #    （正文在 ② 中已处理，这里补摘要区与致谢正文）
    # ------------------------------------------------------------------
    for p in ps:
        st = p.style.name
        if st in ('p17', 'p0') and p.text.strip():
            fmt_para(p, align=WD_ALIGN_PARAGRAPH.JUSTIFY, line=1.0,
                     before=HALF_LINE, after=HALF_LINE)
            fmt_runs(p, ea_font=SONG, size=SZ_WU)

    # ------------------------------------------------------------------
    # ⑦ 页眉页脚（内容见样文）：第 2 节正文页眉居中论文题目，页脚页码
    # ------------------------------------------------------------------
    sec = doc.sections[-1]
    hdr = sec.header
    hdr.is_linked_to_previous = False
    if hdr.paragraphs:
        hp = hdr.paragraphs[0]
        text = hp.text.strip()
        # 页眉内容已存在则只做居中与小五宋体处理
        hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if not text:
            hp.text = '深圳大学本科毕业论文—基于Android的步行者跑步软件开发'
        for r in hp.runs:
            set_run_font(r, ascii_font=WESTERN, ea_font=SONG, size=SZ_XIAO_WU)

    ftr = sec.footer
    ftr.is_linked_to_previous = False
    if ftr.paragraphs:
        fp = ftr.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in fp.runs:
            set_run_font(r, ascii_font=WESTERN, ea_font=SONG, size=SZ_XIAO_WU)

    doc.save(OUT)
    print('saved:', OUT)


if __name__ == '__main__':
    main()
