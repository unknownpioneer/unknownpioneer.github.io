"""Shared OOXML helpers for the 实验1 Word exercises."""
from docx.shared import Pt, RGBColor, Cm, Emu
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'


def el(tag, **attrs):
    e = OxmlElement(tag)
    for k, v in attrs.items():
        e.set(qn('w:' + k), str(v))
    return e


def sub(parent, tag, **attrs):
    e = el(tag, **attrs)
    parent.append(e)
    return e


def set_run_font(run, ascii_font=None, ea_font=None, size=None, bold=None,
                 color=None, underline=None, ucolor=None):
    rPr = run._element.get_or_add_rPr()
    if ascii_font or ea_font:
        rf = rPr.find(qn('w:rFonts'))
        if rf is None:
            rf = OxmlElement('w:rFonts')
            rPr.insert(0, rf)
        if ascii_font:
            rf.set(qn('w:ascii'), ascii_font)
            rf.set(qn('w:hAnsi'), ascii_font)
        if ea_font:
            rf.set(qn('w:eastAsia'), ea_font)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)
    if underline is not None:
        run.font.underline = underline
    if ucolor is not None:
        u = rPr.find(qn('w:u'))
        if u is None:
            u = OxmlElement('w:u')
            rPr.append(u)
        u.set(qn('w:color'), ucolor)


def set_para_columns(paragraph, num, space_twips=425, sep=False):
    """Attach a sectPr to a paragraph, ending a section after it."""
    pPr = paragraph._element.get_or_add_pPr()
    old = pPr.find(qn('w:sectPr'))
    if old is not None:
        pPr.remove(old)
    sect = OxmlElement('w:sectPr')
    cols = OxmlElement('w:cols')
    cols.set(qn('w:num'), str(num))
    cols.set(qn('w:space'), str(space_twips))
    cols.set(qn('w:equalWidth'), '1')
    if sep:
        cols.set(qn('w:sep'), '1')
    sect.append(cols)
    pPr.append(sect)
    return sect


def set_section_columns(section, num, space_twips=425, sep=False):
    sectPr = section._sectPr
    old = sectPr.find(qn('w:cols'))
    if old is not None:
        sectPr.remove(old)
    cols = OxmlElement('w:cols')
    cols.set(qn('w:num'), str(num))
    cols.set(qn('w:space'), str(space_twips))
    cols.set(qn('w:equalWidth'), '1')
    if sep:
        cols.set(qn('w:sep'), '1')
    sectPr.append(cols)
    return cols


def add_field(paragraph, instr, placeholder='1', font=None, size=None,
              ea=None, color=None):
    """Append a simple Word field (e.g. PAGE, NUMPAGES, char count) to a paragraph."""
    r1 = paragraph.add_run()
    fc = el('w:fldChar', fldCharType='begin')
    r1._element.append(fc)
    r2 = paragraph.add_run()
    it = OxmlElement('w:instrText')
    it.set(qn('xml:space'), 'preserve')
    it.text = instr
    r2._element.append(it)
    r3 = paragraph.add_run()
    r3._element.append(el('w:fldChar', fldCharType='separate'))
    r4 = paragraph.add_run(placeholder)
    r5 = paragraph.add_run()
    r5._element.append(el('w:fldChar', fldCharType='end'))
    for r in (r1, r2, r3, r4, r5):
        if font or ea or size is not None or color:
            set_run_font(r, ascii_font=font, ea_font=ea, size=size, color=color)
    return r4


def set_bg_shading(run, fill):
    rPr = run._element.get_or_add_rPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill)
    rPr.append(shd)


def set_char_border(run, color='auto', sz=4):
    rPr = run._element.get_or_add_rPr()
    bdr = OxmlElement('w:bdr')
    bdr.set(qn('w:val'), 'single')
    bdr.set(qn('w:sz'), str(sz))
    bdr.set(qn('w:space'), '0')
    bdr.set(qn('w:color'), color)
    rPr.append(bdr)


def new_num_id(numbering_part):
    """Return a fresh numId from numbering.xml."""
    nums = numbering_part.element.find(qn('w:num'))
    ids = []
    for n in numbering_part.element.findall(qn('w:num')):
        ids.append(int(n.get(qn('w:numId'))))
    return max(ids) + 1 if ids else 1
