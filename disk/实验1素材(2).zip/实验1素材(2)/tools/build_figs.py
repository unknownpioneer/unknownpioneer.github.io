"""生成实验报告所需的全部插图。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image
from docx_render import render_docx, render_plain

FIG = os.path.join('结果', '报告图片')
os.makedirs(FIG, exist_ok=True)

SHOT = os.path.join('新建文件夹')


def p(name):
    return os.path.join(FIG, name)


def crop_shot(src, dst, box):
    im = Image.open(src).convert('RGB')
    w, h = im.size
    sx, sy = w / 1920.0, h / 1080.0
    l, t, r, b = box
    im.crop((int(l * sx), int(t * sy), int(r * sx), int(b * sy))).save(dst)
    return dst


def vstack(paths, gap=8, bg='#FFFFFF', align='center'):
    ims = [Image.open(x) for x in paths]
    W = max(i.width for i in ims)
    H = sum(i.height for i in ims) + gap * (len(ims) - 1)
    c = Image.new('RGB', (W, H), bg)
    y = 0
    for i in ims:
        x = (W - i.width) // 2 if align == 'center' else 0
        c.paste(i, (x, y))
        y += i.height + gap
    return c


def hstack(paths, gap=10, bg='#FFFFFF'):
    ims = [Image.open(x) for x in paths]
    H = max(i.height for i in ims)
    W = sum(i.width for i in ims) + gap * (len(ims) - 1)
    c = Image.new('RGB', (W, H), bg)
    x = 0
    for i in ims:
        c.paste(i, (x, 0))
        x += i.width + gap
    return c


TOC_RIGHT = [
    ('摘要', 'Ⅰ'), ('1 引言', '1'),
    ('1.1 研究意义与发展状况', '1'),
    ('1.1.1 研究意义', '1'), ('1.1.2 发展状况', '1'),
    ('1.1.3 开发内容与目标', '1'), ('1.1.4 论文完成的主要工作', '1'),
    ('2 系统的开发原理与方法', '2'),
    ('2.1 SQLite数据库', '2'), ('2.2 MVC开发架构模式', '2'),
    ('2.3 LBS技术', '3'), ('2.4 百度地图', '3'),
    ('2.5 开发工具和环境', '3'),
    ('2.5.1 Eclipse', '3'), ('2.5.2 Android SDK和ADT插件', '3'),
    ('2.5.3 Android体系', '3'),
    ('3 系统设计', '4'),
    ('3.1 需求分析', '4'),
    ('3.2 总体设计', '4'),
    ('3.3 系统流程图', '5'),
    ('3.4 功能模块的实现', '5'),
    ('3.4.1 登录模块', '5'), ('3.4.2 注册模块', '6'),
    ('3.4.3 系统运行效果图', '6'),
    ('4 系统测试', '7'),
    ('4.1 测试环境', '7'), ('4.2 测试内容与结果', '7'),
    ('结束语', '8'), ('参考文献', '8'), ('致谢', '9'),
]


def make_toc_fig():
    from PIL import ImageDraw, ImageFont
    from docx_render import get_font
    W = 760
    rows = len(TOC_RIGHT) + 1
    lh = 34
    H = 60 + rows * lh + 20
    img = Image.new('RGB', (W, H), 'white')
    d = ImageDraw.Draw(img)
    f_t = get_font('黑体', 16, True)
    f_b = get_font('宋体', 10.5)
    tw = f_t.getlength('目　录')
    d.text(((W - tw) / 2, 14), '目　录', font=f_t, fill='#000000')
    y = 58
    for text, page in TOC_RIGHT:
        tw2 = f_b.getlength(text)
        pw = f_b.getlength(page)
        indent = 0
        if text.startswith('1.1.') or text.startswith('2.5.') or text.startswith('3.4.'):
            indent = 42
        elif text[:2] in ('1 ', '2 ', '3 ', '4 ') or text in ('结束语', '参考文献', '致谢', '摘要'):
            indent = 0
        else:
            indent = 22
        d.text((40 + indent, y), text, font=f_b, fill='#000000')
        dots_start = 40 + indent + tw2 + 8
        dots_end = W - 40 - pw - 8
        dx = dots_start
        while dx < dots_end:
            d.text((dx, y), '.', font=f_b, fill='#000000')
            dx += 7
        d.text((W - 40 - pw, y), page, font=f_b, fill='#000000')
        y += lh
    d.rectangle([0, 0, W - 1, H - 1], outline='#BBBBBB')
    img.save(p('case123_toc.png'))
    return p('case123_toc.png')


def build():
    made = []

    # ---- 案例1-1 书签 ----
    made.append(render_docx(r'结果\案例1-1_书签.docx', p('case11_result.png'),
                            max_height_px=300))
    made.append(render_plain([
        '执行 [插入|链接|书签] 命令，打开"书签"对话框；',
        '在"书签名"框中输入：可溶性岩石，单击"添加"按钮；',
        '再次打开"书签"对话框，在列表中选择"可溶性岩石"；',
        '单击"定位"按钮，光标即快速移到该书签处。',
    ], p('case11_steps.png'), title='操作要点（书签的插入与定位）', width=700,
       body_size=12))

    # ---- 案例1-2 个人简历内容 ----
    made.append(render_plain([
        'RESUME',
        '个人简历',
        '姓名：马腾飞',
        '个人概况',
        '姓名：马腾飞、性别：男、出生日期：1993-10-01、籍贯：北京、',
        '现居住地：深圳、学历：本科、毕业院校：深圳大学、',
        '专业：计算机科学与技术、电子邮件：matengfei@126.com、',
        '电话：12345678912',
        '求职目标',
        '软件开发',
        '专业技能',
        '熟悉',
        'J2SE 技术：AWT/Swing，Collection，Thread；客户端技术：Ajax，',
        'CSS，DOM，EL，JSP；数据库技术：Jdbc，Mysql，SQL 2008，Odbc；',
        '服务端技术：Servlet，Struts2。',
        '了解',
        'EJB，GOF，JAF，JAVAMAIL，Jquery，weblogic，websphere。',
        '项目经验',
        '在线交流系统 / 在线考试系统  ……',
        '实践与实习',
        '获奖情况',
        '语言能力',
        '自我评价',
    ], p('case12_content.png'), title='个人简历.docx 的文字内容（表 1-1）',
       width=720, body_size=11))

    # ---- 案例1-3 插入符号 ----
    made.append(render_docx(r'结果\案例1-3_插入符号.docx', p('case13_result.png'),
                            max_height_px=180))
    made.append(render_plain([
        '① 把插入点移至这段文本的最后；',
        '② 执行 [插入|符号] 命令，在"符号"选项卡中：',
        '     字体：Wingdings　　字符代码：83　　来自：符号（十进制）',
        '③ 单击"插入"按钮，再单击"关闭"，符号即插入到文本末尾。',
    ], p('case13_steps.png'), title='操作要点（插入符号）', width=700, body_size=12))

    # ---- 案例1-5 / 1-6 个人简历 ----
    made.append(render_docx('个人简历.docx', p('case15_result.png'),
                            max_height_px=820))
    made.append(render_plain([
        '（一）案例1-5：标题"个人概况"字符格式',
        '字体：楷体；字号：小四；字体颜色：深蓝色（0070C0）；',
        '字符间距：加宽 2 磅；下划线：整行加下划线、颜色橙色；',
        '底纹：淡橙色，应用于"文字"。',
        '',
        '（二）案例1-6：段落格式',
        '"个人概况"段前、段后各 1 行，行距：单倍行距，特殊格式：（无）；',
        '"求职目标"重复案例1-5及本案例的格式设置（自成 1 段）；',
        '"软件开发"：中文宋体、西文 Times New Roman、5 号、加粗，',
        '　　单倍行距，首行缩进 2 字符。',
    ], p('case16_settings.png'), title='格式设置清单', width=720, body_size=11))

    # ---- 案例1-19 题注 ----
    src_thesis = r'结果\习题1_论文原稿_排版完成.docx'
    made.append(render_docx(src_thesis, p('case19_judge.png'), max_height_px=680,
                            start_par=84, end_par=96))
    made.append(render_plain([
        '图 1　主体功能模块图',
        '',
        '图 2　系统总体流程图',
        '',
        '图 3　登录模块图',
    ], p('case19_captions.png'), title='为插图添加的题注（引用|题注|插入题注）',
       width=560, body_size=12))
    made.append(render_plain([
        '方法一：选定要添加题注的图片 → 执行 [引用|题注|插入题注] 命令，',
        '　　　　在"题注"对话框中设置标签与编号，单击"确定"。',
        '方法二：选定图片 → 右击鼠标 → 在快捷菜单中选择"插入题注"。',
    ], p('case19_steps.png'), title='操作要点（手动添加题注）', width=720,
       body_size=12))

    # ---- 案例1-23 目录 ----
    made.append(make_toc_fig())
    made.append(render_plain([
        '① 在空白页输入"目录"，回车，光标放在第 2 行开始（目录插入点）；',
        '② 把 样式1/样式2/样式3 的大纲级别分别设为 1 级、2 级、3 级；',
        '③ 执行 [引用|目录|插入目录] 命令，在对话框中选择显示级别 3，',
        '　　单击"确定"，目录自动生成；',
        '④ 选中目录内容，设置小四号宋体、1.5 倍行距、分散对齐。',
    ], p('case123_steps.png'), title='操作要点（创建论文目录）', width=720,
       body_size=12))

    # ---- 案例1-28/29/30 AI ----
    made.append(render_plain([
        '待润色段落：',
        '荔园大学是一座综合性的大学，它比较重视实践教学的同事，还特别注重创新研究，',
        '吸引了很多多国内和国外的，很多优秀的学子来求学。……梨园大学还和很多的知名',
        '企业以及各大机构建立了比较紧密的合作关系，同时要他们具有创新型的能力。',
    ], p('case28_src.png'), title='原稿与提示词（腾讯元宝 / AI 大模型）', width=760,
       body_size=11))
    made.append(render_plain([
        '荔园大学是一所综合性大学，既重视实践教学，又特别注重创新研究，吸引了众多',
        '国内外优秀学子前来求学。荔园大学不仅为学生提供丰富的学术资源，还配备了先进',
        '的实验室和各类设施。此外，学校与多家知名企业及各类机构建立了紧密的合作关系，',
        '致力于培养一批又一批具有国际视野和创新能力的人才。',
    ], p('case28_out.png'), title='润色结果', width=760, body_size=11,
       title_color='#C00000'))
    made.append(render_plain([
        '荔园大学是一所立足国际大都市、气质自由开明的高水平大学。学校地处经济发达、',
        '信息汇聚的现代化都市，与众多知名企业和科研机构毗邻，为学生提供了丰富的实习',
        '岗位与就业机会，毕业生就业率长期位居同类院校前列。校园学术氛围浓厚，鼓励学生',
        '独立思考、大胆质疑，社团活动与创新创业项目百花齐放……学校还建有设备完善的',
        '实验室和藏书丰富的图书馆，并以开放的姿态与国（境）外高校开展交流合作，帮助',
        '学生拓宽国际视野、提升综合素养，为未来的职业发展打下坚实基础。',
    ], p('case29_out.png'), title='扩写结果（原文：荔园大学，就业率高，位于国际大都市，自由开明）',
       width=760, body_size=11, title_color='#C00000'))
    made.append(render_plain([
        '荔园大学坐落于国际大都市，区位优势显著，校园氛围自由开明。学校依托卓越的',
        '教育质量与紧密的产学研合作，持续保持高就业率；同时以开放包容的姿态汇聚多元',
        '文化，鼓励学生自由探索，并搭建国际交流平台，培养具有全球视野与创新能力的人才，',
        '是众多学子求学与发展的理想之地。',
    ], p('case30_out.png'), title='简写结果（约 110 字的摘要）', width=760,
       body_size=11, title_color='#C00000'))

    # ---- 真实 Word 截图裁切 ----
    try:
        crop_shot(os.path.join(SHOT, '捕获.PNG'), p('shot_fontdialog.png'),
                  (0, 0, 463, 652))
        crop_shot(os.path.join(SHOT, 'screenshot.PNG'), p('shot_resume_p2.png'),
                  (215, 195, 1890, 1050))
        crop_shot(os.path.join(SHOT, '批注 2026-10-13 164403.png'),
                  p('shot_resume_cover.png'), (215, 195, 1890, 1050))
        crop_shot(os.path.join(SHOT, '批注 2026-10-13 162847.png'),
                  p('shot_two_cols.png'), (660, 380, 1460, 940))
        crop_shot(os.path.join(SHOT, 'screeshot04.PNG'), p('shot_thesis_heading.png'),
                  (500, 195, 1380, 900))
        crop_shot(os.path.join(SHOT, 'screenshot05.PNG'), p('shot_crossref.png'),
                  (680, 250, 1170, 700))
    except Exception as exc:
        print('screenshot crop failed:', exc)

    for m in made:
        if m and os.path.exists(m):
            print('ok', os.path.basename(m), os.path.getsize(m))


if __name__ == '__main__':
    build()
