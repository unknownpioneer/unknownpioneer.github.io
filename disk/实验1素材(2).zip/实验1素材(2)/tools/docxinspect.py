import sys, io
from docx import Document
from docx.oxml.ns import qn

out = io.StringIO()

def w(s=''):
    out.write(str(s) + '\n')

for path in sys.argv[1:]:
    w('#' * 70)
    w('FILE: ' + path)
    doc = Document(path)
    sec = doc.sections[0]
    w('sections: %d' % len(doc.sections))
    if sec.page_width is not None and sec.top_margin is not None:
        w('page: w=%.2fcm h=%.2fcm orient=%s' % (sec.page_width.cm, sec.page_height.cm, sec.orientation))
        w('margins cm: top=%.2f bottom=%.2f left=%.2f right=%.2f' % (
            sec.top_margin.cm, sec.bottom_margin.cm, sec.left_margin.cm, sec.right_margin.cm))
    else:
        w('page: (no explicit size/margins)')
    w('body: %d paragraphs, %d tables' % (len(doc.paragraphs), len(doc.tables)))
    for i, p in enumerate(doc.paragraphs):
        if not p.text.strip():
            continue
        pf = p.paragraph_format
        w('[%d] style=%s align=%s firstline=%s left=%s sb=%s sa=%s ls=%s' % (
            i, p.style.name, pf.alignment, pf.first_line_indent,
            pf.left_indent,
            pf.space_before.pt if pf.space_before else None,
            pf.space_after.pt if pf.space_after else None,
            pf.line_spacing))
        w('    TEXT: ' + p.text[:200])
        seen = set()
        for r in p.runs:
            if not r.text.strip():
                continue
            key = r.text[:20]
            if key in seen:
                continue
            seen.add(key)
            f = r.font
            ea = None
            if r._element.rPr is not None and r._element.rPr.rFonts is not None:
                ea = r._element.rPr.rFonts.get(qn('w:eastAsia'))
            try:
                col = f.color.rgb if (f.color is not None and f.color.type is not None) else None
            except Exception:
                col = None
            w('    RUN %r font=%s eastAsia=%s size=%s bold=%s underline=%s color=%s' % (
                r.text[:30], f.name, ea, f.size.pt if f.size else None, f.bold, f.underline, col))
    for ti, t in enumerate(doc.tables):
        w('TABLE %d: %d rows x %d cols' % (ti, len(t.rows), len(t.columns)))
        for row in t.rows[:12]:
            w('    | ' + ' | '.join(c.text.strip().replace('\n', ' ') for c in row.cells))

with open(sys.argv[0].rsplit('\\', 1)[0] + '\\inspect_out.txt', 'w', encoding='utf-8') as f:
    f.write(out.getvalue())
print('written', len(out.getvalue()))
